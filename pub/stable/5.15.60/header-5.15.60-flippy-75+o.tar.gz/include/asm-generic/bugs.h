/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_GENERIC_BUGS_H
#define __ASM_GENERIC_BUGS_H
/*
 * This file is included by 'init/main.c' to check for
 * architecture-dependent bugs.
 */

static inline void check_bugs(void) { }

#endif	/* __ASM_GENERIC_BUGS_H */
